Total heating due to neutrons [W]:
      total      1.42709E-08 0.0211
Total heating due to photons  [W]:
      total      2.34139E-07 0.0108
The total heating in the detector is the sum of these two numbers.
