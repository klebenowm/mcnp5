Neutron dose (line 486):
      total      1.15794E-02 0.0056
Photon dose (line 723):
      total      1.09869E+08 0.1153

Note that both of these doses are products of the uncollided flux.
