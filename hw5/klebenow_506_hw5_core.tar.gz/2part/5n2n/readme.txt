As shown in line 380 of the outp file, the number of (n,2n) 
reactions per second is:
      total      1.52566E+05 0.0020
