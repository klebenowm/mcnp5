The appropriate enrichment is:
M1 1001 2 8016 1 92235 0.00649 92238 0.09351

Which provides a keff of 0.99942
