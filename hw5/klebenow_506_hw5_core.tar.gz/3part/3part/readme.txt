Plots have been provided with appropriate filenames.
